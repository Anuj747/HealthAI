import React from 'react';
import { Routes, Route } from 'react-router-dom';
import Navbar from './components/Navbar';
import Chatbox from './components/Chatbox';
import Home from './pages/Home';
import Tracker from './pages/Tracker';
import History from './pages/History';
import MBBSChat from './pages/MBBSChat';
import BAMSChat from './pages/BAMSChat';
import BDSChat from './pages/BDSChat';
import './App.css';

function App(){
  return (
    <div>
      <Navbar />
      <Routes>
        <Route path='/' element={<Home/>} />
        <Route path='/tracker' element={<Tracker/>} />
        <Route path='/history' element={<History/>} />
        <Route path='/chat/mbbs' element={<MBBSChat/>} />
        <Route path='/chat/bams' element={<BAMSChat/>} />
        <Route path='/chat/bds' element={<BDSChat/>} />
      </Routes>
      <Chatbox />
    </div>
  );
}

export default App;
