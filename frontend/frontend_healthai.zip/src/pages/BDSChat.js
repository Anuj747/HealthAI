import React, { useState } from 'react';
export default function BDSChat(){
  const [msgs, setMsgs] = useState([]);
  const [text, setText] = useState('');
  const replies = [
    'Apply clove oil on the affected tooth and rinse with warm salt water. If swelling appears, see a dentist.',
    'Use soft brush and avoid very hot/cold foods until pain subsides.'
  ];
  function send(){
    if(!text.trim()) return;
    setMsgs(m=>[...m, {who:'user', text}]);
    setText('');
    setTimeout(()=> setMsgs(m=>[...m, {who:'bot', text: replies[Math.floor(Math.random()*replies.length)]}]), 700);
  }
  return (
    <main className="container">
      <section className="card">
        <h2>BDS Assistant</h2>
        <p style={{color:'var(--muted)'}}>Dental temporary guidance (demo).</p>
        <div style={{marginTop:12}}>
          <div style={{height:300, overflow:'auto', padding:12, borderRadius:12, background:'rgba(255,255,255,0.02)'}}>
            {msgs.map((m,i)=>(<div key={i} style={{marginBottom:8, textAlign: m.who==='user' ? 'right' : 'left'}}>{m.text}</div>))}
          </div>
          <div style={{display:'flex', gap:8, marginTop:8}}>
            <textarea value={text} onChange={(e)=> setText(e.target.value)} style={{flex:1, borderRadius:10, padding:10}} rows={3} />
            <button className="btn" onClick={send}>Send</button>
          </div>
        </div>
      </section>
    </main>
  );
}
