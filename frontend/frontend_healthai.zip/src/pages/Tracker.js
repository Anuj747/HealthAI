import React from 'react';
export default function Tracker(){
  return (
    <main className="container">
      <section className="card">
        <h2>Daily Health Tracker</h2>
        <p style={{color:'var(--muted)'}}>Add your daily vitals. (Backend integration required to persist data).</p>
        <div style={{marginTop:16}} className="card">
          <form>
            <div style={{display:'flex', gap:10, marginBottom:10}}>
              <input placeholder="Blood pressure (120/80)" style={{flex:1, padding:10, borderRadius:10, background:'transparent', border:'1px solid rgba(255,255,255,0.06)'}} />
              <input placeholder="Sugar (mg/dL)" style={{flex:1, padding:10, borderRadius:10, background:'transparent', border:'1px solid rgba(255,255,255,0.06)'}} />
            </div>
            <div style={{display:'flex', gap:10}}>
              <input placeholder="Weight (kg)" style={{flex:1, padding:10, borderRadius:10, background:'transparent', border:'1px solid rgba(255,255,255,0.06)'}} />
              <input placeholder="Sleep hours" style={{flex:1, padding:10, borderRadius:10, background:'transparent', border:'1px solid rgba(255,255,255,0.06)'}} />
            </div>
            <div style={{marginTop:12}}>
              <button className="btn" type="button">Save</button>
            </div>
          </form>
        </div>
      </section>
    </main>
  );
}
