import React, { useState } from 'react';
export default function MBBSChat(){
  const [msgs, setMsgs] = useState([]);
  const [text, setText] = useState('');
  const replies = [
    'You can take paracetamol 500mg every 6-8 hours for fever. If fever exceeds 102°F or continues >48 hours, visit a doctor.',
    'Stay hydrated, rest, and monitor symptoms. If breathing difficulty appears, seek immediate care.'
  ];
  function send(){
    if(!text.trim()) return;
    setMsgs(m=>[...m, {who:'user', text}]);
    setText('');
    setTimeout(()=> setMsgs(m=>[...m, {who:'bot', text: replies[Math.floor(Math.random()*replies.length)]}]), 700);
  }
  return (
    <main className="container">
      <section className="card">
        <h2>MBBS Assistant</h2>
        <p style={{color:'var(--muted)'}}>General medicine temporary guidance (demo).</p>
        <div style={{marginTop:12}}>
          <div style={{height:300, overflow:'auto', padding:12, borderRadius:12, background:'rgba(255,255,255,0.02)'}}>
            {msgs.map((m,i)=>(<div key={i} style={{marginBottom:8, textAlign: m.who==='user' ? 'right' : 'left'}}>{m.text}</div>))}
          </div>
          <div style={{display:'flex', gap:8, marginTop:8}}>
            <textarea value={text} onChange={(e)=> setText(e.target.value)} style={{flex:1, borderRadius:10, padding:10}} rows={3} />
            <button className="btn" onClick={send}>Send</button>
          </div>
        </div>
      </section>
    </main>
  );
}
