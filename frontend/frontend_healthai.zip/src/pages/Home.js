import React from 'react';
export default function Home(){
  return (
    <main className="container">
      <section className="card hero">
        <div>
          <h1 style={{fontSize:30, margin:0}}>Track your health. Chat with specialized AI.</h1>
          <p style={{color:'var(--muted)', marginTop:12}}>HealthAI helps you record vitals, manage medications, store history, and ask MBBS/BAMS/BDS assistants for temporary guidance.</p>
          <div style={{marginTop:18, display:'flex', gap:10}}>
            <a className="btn" href="/chat/mbbs">Open Chat</a>
            <a className="btn" href="/tracker" style={{opacity:0.95}}>Open Tracker</a>
          </div>
        </div>

        <div style={{display:'flex',alignItems:'center',justifyContent:'center'}}>
          <div style={{width:360,height:360,borderRadius:18,background:'linear-gradient(135deg, rgba(255,255,255,0.02), rgba(255,255,255,0.01))', border:'1px solid rgba(255,255,255,0.03)', display:'flex',alignItems:'center',justifyContent:'center', flexDirection:'column', padding:20}}>
            <img src={'https://via.placeholder.com/220x220.png?text=AI+Doc'} alt="ai" style={{borderRadius:12}}/>
            <div style={{marginTop:14, color:'var(--muted)', fontSize:14}}>Your pocket health assistant</div>
          </div>
        </div>
      </section>

      <section style={{marginTop:28}}>
        <div className="card">
          <h3>Why HealthAI?</h3>
          <p style={{color:'var(--muted)'}}>Simple, private, and helpful. Built to give quick guidance and encourage professional consultations when necessary.</p>
        </div>
      </section>
    </main>
  );
}
