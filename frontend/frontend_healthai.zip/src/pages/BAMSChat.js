import React, { useState } from 'react';
export default function BAMSChat(){
  const [msgs, setMsgs] = useState([]);
  const [text, setText] = useState('');
  const replies = [
    'Try turmeric milk and ginger for inflammation. Adjust diet; avoid oily foods for 24-48 hours.',
    'Ayurvedic teas with tulsi and ginger can soothe mild respiratory symptoms.'
  ];
  function send(){
    if(!text.trim()) return;
    setMsgs(m=>[...m, {who:'user', text}]);
    setText('');
    setTimeout(()=> setMsgs(m=>[...m, {who:'bot', text: replies[Math.floor(Math.random()*replies.length)]}]), 700);
  }
  return (
    <main className="container">
      <section className="card">
        <h2>BAMS Assistant</h2>
        <p style={{color:'var(--muted)'}}>Ayurveda suggestions (demo).</p>
        <div style={{marginTop:12}}>
          <div style={{height:300, overflow:'auto', padding:12, borderRadius:12, background:'rgba(255,255,255,0.02)'}}>
            {msgs.map((m,i)=>(<div key={i} style={{marginBottom:8, textAlign: m.who==='user' ? 'right' : 'left'}}>{m.text}</div>))}
          </div>
          <div style={{display:'flex', gap:8, marginTop:8}}>
            <textarea value={text} onChange={(e)=> setText(e.target.value)} style={{flex:1, borderRadius:10, padding:10}} rows={3} />
            <button className="btn" onClick={send}>Send</button>
          </div>
        </div>
      </section>
    </main>
  );
}
