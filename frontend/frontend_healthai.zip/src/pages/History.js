import React from 'react';
export default function History(){
  return (
    <main className="container">
      <section className="card">
        <h2>Medical History</h2>
        <p style={{color:'var(--muted)'}}>Upload prescriptions and reports. (Backend integration required).</p>
        <div style={{marginTop:12}} className="card">
          <label>Upload report</label>
          <input type="file" />
          <div style={{marginTop:10}}><button className="btn" type="button">Upload</button></div>
        </div>
      </section>
    </main>
  );
}
