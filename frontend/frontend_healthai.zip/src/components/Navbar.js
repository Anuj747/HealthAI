import React from 'react';
import { Link } from 'react-router-dom';
export default function Navbar(){
  return (
    <header className="navbar">
      <Link className="brand" to="/">
        <div className="logo">H</div>
        <div style={{display:'flex', flexDirection:'column'}}>
          <div style={{fontWeight:800}}>HealthAI</div>
          <div style={{fontSize:11, color:'var(--muted)'}}>AI health companion</div>
        </div>
      </Link>
      <nav className="navlinks">
        <Link to="/">Home</Link>
        <Link to="/tracker">Tracker</Link>
        <Link to="/history">History</Link>
        <Link to="/chat/mbbs">AI Chat</Link>
      </nav>
    </header>
  );
}
