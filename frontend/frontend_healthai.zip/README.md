# HealthAI Frontend

This is the frontend for HealthAI (React). After unzipping, run `npm install` then `npm start`.
